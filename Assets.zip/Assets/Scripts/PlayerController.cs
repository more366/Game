using UnityEngine;

public class PlayerController: MonoBehaviour
{
    public float moveSpeed = 5f;
    public Sprite[] upSprites;
    public Sprite[] downSprites;
    public Sprite[] leftSprites;
    public Sprite[] rightSprites;

    private SpriteRenderer spriteRenderer;
    private int currentSpriteIndex = 0;
    private float animationTimer = 0.1f; // ����� ��� ����� ��������
    private float timer = 0f;

    // ����� ��������� ������ ��� ����������� ��������
    private Sprite idleUpSprite;
    private Sprite idleDownSprite;
    private Sprite idleLeftSprite;
    private Sprite idleRightSprite;

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        idleUpSprite = upSprites[0];
        idleDownSprite = downSprites[0];
        idleLeftSprite = leftSprites[0];
        idleRightSprite = rightSprites[0];
    }

    void FixedUpdate()
    {
        Move();
    }

    void Move()
    {
        Vector3 moveDirection = Vector3.zero;

        if (Input.GetKey(KeyCode.W))
        {
            moveDirection += Vector3.up;
            ChangeAnimation(upSprites);
        }
        else if (Input.GetKey(KeyCode.S))
        {
            moveDirection += Vector3.down;
            ChangeAnimation(downSprites);
        }
        if (Input.GetKey(KeyCode.A))
        {
            moveDirection += Vector3.left;
            ChangeAnimation(leftSprites);
        }
        else if (Input.GetKey(KeyCode.D))
        {
            moveDirection += Vector3.right;
            ChangeAnimation(rightSprites);
        }

        if (moveDirection != Vector3.zero)
        {
            transform.position += moveDirection.normalized * moveSpeed * Time.fixedDeltaTime;
        }
        else
        {
            // ������������� ��������� ������ � ����������� �� ���������� �����������
            if (currentSpriteIndex < upSprites.Length && spriteRenderer.sprite == upSprites[currentSpriteIndex])
            {
                spriteRenderer.sprite = idleUpSprite;
            }
            else if (currentSpriteIndex < downSprites.Length && spriteRenderer.sprite == downSprites[currentSpriteIndex])
            {
                spriteRenderer.sprite = idleDownSprite;
            }
            else if (currentSpriteIndex < leftSprites.Length && spriteRenderer.sprite == leftSprites[currentSpriteIndex])
            {
                spriteRenderer.sprite = idleLeftSprite;
            }
            else if (currentSpriteIndex < rightSprites.Length && spriteRenderer.sprite == rightSprites[currentSpriteIndex])
            {
                spriteRenderer.sprite = idleRightSprite;
            }
        }
    }

    void ChangeAnimation(Sprite[] sprites)
    {
        timer += Time.deltaTime;
        if (timer >= animationTimer)
        {
            currentSpriteIndex = (currentSpriteIndex + 1) % sprites.Length;
            spriteRenderer.sprite = sprites[currentSpriteIndex];
            timer = 0f;
        }
    }
}
