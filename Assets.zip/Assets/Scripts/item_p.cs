using System.Collections;
using System.Collections.Generic;

using UnityEngine;



public class item_p : MonoBehaviour
{
    public GameObject inv;

    // Start is called before the first frame update
    void Start()
    {
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        inv.GetComponent<change_item>().addItem(3);

        GameObject.Destroy(gameObject);
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
