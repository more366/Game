using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class useInventory: MonoBehaviour
{
    [SerializeField] public GameObject inventoryPol;
    private bool isOpen = true;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void changeInventory()
    {
        StartCoroutine(ChangeInventoryCoroutine());
    }

    private IEnumerator ChangeInventoryCoroutine()
    {
        yield return new WaitForSeconds(0.5f); // ��� 2 �������

        if (isOpen)
        {
            inventoryPol.SetActive(false);
        }
        else
        {
            inventoryPol.SetActive(true);
        }

        isOpen = !isOpen; // ����������� �������� isOpen
    }
}
