using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class change_item : MonoBehaviour
{
    public GameObject wheel_1;
    public GameObject soup_1;
    public GameObject mech_box_1;

    public GameObject wheel_2;
    public GameObject soup_2;
    public GameObject mech_box_2;

    public GameObject wheel_3;
    public GameObject soup_3;
    public GameObject mech_box_3;

    public GameObject wheel_4;
    public GameObject soup_4;
    public GameObject mech_box_4;

    public GameObject wheel_5;
    public GameObject soup_5;
    public GameObject mech_box_5;

    public GameObject wheel_6;
    public GameObject soup_6;
    public GameObject mech_box_6;
    ArrayList inventory = new ArrayList();

    // Start is called before the first frame update
    private void Start()
    {
        
    }
    


    // Update is called once per frame
    void Update()
    {

    }
    // 1 - ��� ��������
    // 2 - ��� ���
    // 3 - ����
    public void addItem(int Item) {
        inventory.Add(Item);
        buildInventory(inventory);
    }
    public bool removeItem(int Item)
    {
        if (inventory.Contains(Item))
        {
            inventory.Remove(Item);
            buildInventory(inventory);
        }
        return inventory.Contains(Item);
        // ������ true ���� ����� ������� ���� � �� ��� ������
        // ������ false ���� � ��������� ��� ���
    }
    //���� ����� �� ��� ������
    public void removeItem_without_answer(int Item)
    {
        if (inventory.Contains(Item))
        {
            inventory[inventory.IndexOf(Item)] = 0;
            buildInventory(inventory);
        }
        
        // ������ true ���� ����� ������� ���� � �� ��� ������
        // ������ false ���� � ��������� ��� ���
    }
    void buildInventory(ArrayList inventory) {
        int[] inv = inventory.ToArray(typeof(int)) as int[];
        Debug.Log(inv);
        for (int i = 0; i < inv.Length; i++)
        {
            Debug.Log(i + " ��� i");
            Debug.Log(inv[i] + "��� ��������");
            if (i == 0) {
                if (inv[i] == 1) {
                    
                    soup_1.SetActive(false);
                    mech_box_1.SetActive(false);
                    wheel_1.SetActive(true);
                }
                if (inv[i] == 2)
                {
                    
                    soup_1.SetActive(true);
                    mech_box_1.SetActive(false);
                    wheel_1.SetActive(false);
                }
                if (inv[i] == 3)
                {
                    soup_1.SetActive(false);
                    mech_box_1.SetActive(true);
                    wheel_1.SetActive(false);
                }
                if (inv[i] == 0) {
                    soup_1.SetActive(false);
                    mech_box_1.SetActive(false);
                    wheel_1.SetActive(false);
                }
            }
            if (i == 1)
            {
                if (inv[i] == 1)
                {
                    Debug.Log("������� ��������� (rjktcj)");
                    soup_2.SetActive(false);
                    mech_box_2.SetActive(false);
                    wheel_2.SetActive(true);
                }
                if (inv[i] == 2)
                {
                    soup_2.SetActive(true);
                    mech_box_2.SetActive(false);
                    wheel_2.SetActive(false);
                }
                if (inv[i] == 3)
                {
                    soup_2.SetActive(false);
                    mech_box_2.SetActive(true);
                    wheel_2.SetActive(false);
                }

            }
            if (i == 2)
            {
                if (inv[i] == 1)
                {
                    soup_3.SetActive(false);
                    mech_box_3.SetActive(false);
                    wheel_3.SetActive(true);
                }
                if (inv[i] == 2)
                {
                    soup_3.SetActive(true);
                    mech_box_3.SetActive(false);
                    wheel_3.SetActive(false);
                }
                if (inv[i] == 3)
                {
                    soup_3.SetActive(false);
                    mech_box_3.SetActive(true);
                    wheel_3.SetActive(false);
                }
            }
            if (i == 3)
            {
                if (inv[i] == 1)
                {
                    soup_4.SetActive(false);
                    mech_box_4.SetActive(false);
                    wheel_4.SetActive(true);
                }
                if (inv[i] == 2)
                {
                    soup_4.SetActive(true);
                    mech_box_4.SetActive(false);
                    wheel_4.SetActive(false);
                }
                if (inv[i] == 3)
                {
                    soup_4.SetActive(false);
                    mech_box_4.SetActive(true);
                    wheel_4.SetActive(false);
                }
            }
            if (i == 4)
            {
                if (inv[i] == 1)
                {
                    soup_5.SetActive(false);
                    mech_box_5.SetActive(false);
                    wheel_5.SetActive(true);
                }
                if (inv[i] == 2)
                {
                    soup_5.SetActive(true);
                    mech_box_5.SetActive(false);
                    wheel_5.SetActive(false);
                }
                if (inv[i] == 3)
                {
                    soup_5.SetActive(false);
                    mech_box_5.SetActive(true);
                    wheel_5.SetActive(false);
                }
            }
            if (i == 5)
            {
                if (inv[i] == 1)
                {
                    soup_6.SetActive(false);
                    mech_box_6.SetActive(false);
                    wheel_6.SetActive(true);
                }
                if (inv[i] == 2)
                {
                    soup_6.SetActive(true);
                    mech_box_6.SetActive(false);
                    wheel_6.SetActive(false);
                }
                if (inv[i] == 3)
                {
                    soup_6.SetActive(false);
                    mech_box_6.SetActive(true);
                    wheel_6.SetActive(false);
                }
            }
        }
    }
}
