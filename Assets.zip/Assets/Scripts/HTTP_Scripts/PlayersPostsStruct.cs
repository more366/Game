
namespace DefaultNameSpace {
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using UnityEngine;

    [System.Serializable]
    public struct PostStructPlayers
    {
        public string name;
        public string resources;

    }
    public struct Resourr
    {
        public string pass;
        public int honey;
    }

}

